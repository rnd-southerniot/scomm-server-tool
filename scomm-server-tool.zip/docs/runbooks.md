## Gateway Silent
- Check last uplink age
- Verify MQTT publish
- Inspect RF stats
